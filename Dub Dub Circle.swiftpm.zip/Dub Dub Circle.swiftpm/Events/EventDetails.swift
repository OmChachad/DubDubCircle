//
//  EventDetails.swift
//  Dub Dub Circle
//
//  Created by Om Chachad on 2/2/25.
//

import SwiftUI
import SwiftData

struct EventDetails: View {
    var event: DeveloperEvent
    
    enum ViewStyle {
        case list, circular
    }
    
    @State private var viewStyle: ViewStyle = .circular
    @State private var showNewAttendeeView = false
    
    @Namespace var namespace
    
    @State private var showMemoriesView = false
    @State private var showJournalView = false
    
    var body: some View {
        NavigationStack {
            Spacer()
            
            Text("My **\(event.title)** Circle")
                .font(.largeTitle)
                .accessibilityAddTraits(.isHeader)
            Text(event.date, style: .date)
                .font(.title2)
                .foregroundStyle(.secondary)
                .accessibilityLabel("Event date: \(event.date.formatted(date: .long, time: .omitted))")
            
            if event.attendees.count > 0 {
                Picker("View Style", selection: $viewStyle.animation()) {
                    
                    Image(systemName: "circle.dotted")
                        .tag(ViewStyle.circular)
                    
                    Image(systemName: "list.bullet")
                        .tag(ViewStyle.list)
                    
                }
                .pickerStyle(.segmented)
                .labelsHidden()
                .frame(width: 80)
                .accessibilityLabel("View style picker")
                .accessibilityValue(viewStyle == .circular ? "Circular view" : "List view")
                .accessibilityHint("Change between circular and list view of attendees")
            }
                
            
            switch viewStyle {
            case .list:
                Group {
                    List {
                        ForEach(event.attendees, id: \.self) { attendee in
                            AttendeeItem(attendee: attendee, namespace: namespace, viewStyle: .list)
                                .listRowBackground(Color(uiColor: .systemGray6))
                        }
                    }
                    .listStyle(.plain)
                    .background(Color(uiColor: .systemGray6))
                    .clipShape(RoundedRectangle(cornerRadius: 20, style: .continuous))
                    .contentMargins(.bottom, 120, for: .scrollContent)
                    .contentMargins(.bottom, 110, for: .scrollIndicators)
                    .padding()
                    .accessibilityLabel("Attendees list")
                    .accessibilityValue("\(event.attendees.count) \(event.attendees.count == 1 ? "attendee" : "attendees")")
                }
                .frame(maxHeight: .infinity, alignment: .top)
            case .circular:
                ZStack {
                    MyProfileCircle()
                        .glow()
                        .frame(width: 150, height: 150)
                        .zIndex(2)
                        .accessibilityLabel("Your profile")
                        .accessibilityHint("Double tap to edit your profile")
                    
                    CircularList {
                        ForEach(event.attendees, id: \.self) { attendee in
                            AttendeeItem(attendee: attendee, namespace: namespace, viewStyle: .circular)
                        }
                        
                        if event.attendees.count%7 != 0 || event.attendees.count == 0 {
                            ForEach((event.attendees.count%7)..<6, id: \.self) { _ in
                                Button {
                                    showNewAttendeeView = true
                                } label: {
                                    Circle()
                                        .foregroundStyle(Color(uiColor: .systemGray5))
                                }
                                .accessibilityLabel("Add attendee")
                                .accessibilityHint("Double tap to add a new attendee to this event")
                            }
                        }
                        
                        Button {
                            showNewAttendeeView = true
                        } label: {
                            Circle()
                                .foregroundStyle(Color(uiColor: .systemGray5))
                                .overlay(Image(systemName: "plus").font(.largeTitle).foregroundStyle(.blue))
                        }
                        .accessibilityLabel("Add attendee")
                        .accessibilityHint("Double tap to add a new attendee to this event")
                    }
                    .accessibilityElement(children: .contain)
                    .accessibilityLabel("Circular attendee view")
                    .accessibilityValue("\(event.attendees.count) \(event.attendees.count == 1 ? "attendee" : "attendees")")
                }
                .frame(maxHeight: 700)
                .padding(.bottom, event.attendees.count%7 == 0 && event.attendees.count != 0 ? 65 : 40)
            }
            
            Spacer()
        }
        .onChange(of: event) {
            if event.attendees.count == 0 {
                viewStyle = .circular
            }
        }
        .overlay(alignment: .bottom) {
            HStack(alignment: .center) {
                Button {
                    showMemoriesView = true
                } label: {
                    Label("Memories", systemImage: "photo.on.rectangle.angled.fill")
                        .foregroundStyle(AngularGradient(
                            gradient: Gradient(colors: [
                                Color(red: 250/255, green: 84/255, blue: 92/255),   // rgb(250, 84, 92)
                                Color(red: 154/255, green: 189/255, blue: 19/255),  // rgb(154, 189, 19)
                                Color(red: 103/255, green: 172/255, blue: 225/255), // rgb(103, 172, 225)
                                Color(red: 103/255, green: 172/255, blue: 225/255),  // rgb(103, 172, 225)
                                Color(red: 250/255, green: 84/255, blue: 92/255)
                            ]),
                            center: .center
                        ))
                        .font(.title)
                        .labelStyle(.iconOnly)
                        .frame(width: 65, height: 65)
//                        .background(Color.white, in: .circle)
                        .bold()
                }
                .buttonBorderShape(.circle)
                .buttonStyle(.glassProminent)
                .tint(.white)
                .accessibilityLabel("Memories")
                .accessibilityHint("Double tap to view and add photos from this event")
                .sheet(isPresented: $showMemoriesView) {
                    MemoriesView(event: event)
                }
                
                Spacer()
                
                if (event.attendees.count%7 == 0 && event.attendees.count != 0) || viewStyle == .list{
                    Button {
                        showNewAttendeeView = true
                    } label: {
                        Label("Add Attendee", systemImage: "person.fill.badge.plus")
                            .foregroundStyle(.white)
                            .padding(10)
                            .bold()
                    }
                    .buttonStyle(.glassProminent)
                    .tint(Color.accentColor.gradient)
                    .accessibilityLabel("Add attendee")
                    .accessibilityHint("Double tap to add a new attendee to this event")
                }
                
                Spacer()
                
                Button {
                    showJournalView = true
                } label: {
                    Label("Journal", systemImage: "pencil.and.list.clipboard")
                        .foregroundStyle(.white)
                        .font(.title)
                        .labelStyle(.iconOnly)
                        .frame(width: 65, height: 65)
                        .bold()
                }
                .buttonBorderShape(.circle)
                .buttonStyle(.glassProminent)
                .tint(Color.indigo.gradient)
//                .shadow(color: .black.opacity(0.2), radius: 10, x: 0, y: 10)
                .accessibilityLabel("Journal")
                .accessibilityHint("Double tap to view and write journal entries about this event")
                .sheet(isPresented: $showJournalView) {
                    JournalView(event: event)
                }
            }
            .padding(5)
            .padding(.horizontal)
            .background {
                if viewStyle == .list {
                    Rectangle()
                        .fill(.clear)
                        .background(Color.primary.colorInvert())
                        .background(.ultraThinMaterial)
                        .mask {
                            Rectangle()
                                .fill(LinearGradient(colors: [.clear, .white, .white, .white, .white], startPoint: .top, endPoint: .bottom))
                        }
                        .frame(height: 150)
                        .frame(maxWidth: .infinity)
                        .ignoresSafeArea(.all)
                        .accessibilityHidden(true)
                }
            }
            .sheet(isPresented: $showNewAttendeeView) {
                NewAttendeeView(event: event)
            }
        }
    }
}

#Preview {
    let event = DeveloperEvent(title: "WWDC", date: Date(), wasOnline: true)
    EventDetails(event: event)
}
